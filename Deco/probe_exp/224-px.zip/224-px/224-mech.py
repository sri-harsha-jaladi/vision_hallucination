import requests
import torch

from PIL import Image
from pathlib import Path

from prismatic import load

device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")

model_id = "clip-224px+7b"
vlm = load(model_id, hf_token=None)
vlm.to(device, dtype=torch.float16)


def get_single_res(text, image):
    print(text)
    print(image)
    # Download an image and specify a prompt
    image_path = image
    image = Image.open(image_path).convert("RGB")
    
    input_dict = vlm.llm_backbone.tokenizer(text, truncation=True, return_tensors="pt")
    input_ids = input_dict.input_ids.to(vlm.device)
    attention_mask = input_dict.attention_mask.to(vlm.device)
    pixel_values = vlm.vision_backbone.image_transform(image)
    pixel_values = pixel_values[None, ...].to(vlm.device,dtype=torch.float16)
    generated_text = vlm(
        input_ids=input_ids,
        attention_mask=attention_mask,
        pixel_values=pixel_values,
        output_hidden_states=True
    )
    print(generated_text.hidden_states[0].shape)
    return generated_text.hidden_states



from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score
import pandas as pd
from probe_mllmmech_dataload import *
total_steps = 800
trainset = generate_n_doable_examples(total_steps, vlm.llm_backbone.tokenizer)
evalset = get_test_data(vlm.llm_backbone.tokenizer)



print(trainset[:2])
print("=========")
print(len(evalset))
print(evalset[:2])


stats = []
num_layers = 32 


label_mapping = {4874: 0, 694: 1}#yes:4874, no:694

train_activation = [[] for _ in range(32)]
train_label = [[] for _ in range(32)]

test_activation = [[] for _ in range(32)]
test_label = [[] for _ in range(32)]

# loop over layers and positions
with torch.no_grad():
    # activations, labels = [], []
    print("====================loading train set activation====================")
    iterator_train = tqdm(trainset)
    for example in iterator_train:
        # forward pass
        base_inputs = example.base
        base_activations = get_single_res(base_inputs["text"], base_inputs["image"])
        
        src_inputs = example.src
        src_activations = get_single_res(src_inputs["text"], src_inputs["image"])
         
        # 1 ~ 32
        for i in range(1, 33):
            train_activation[i - 1].extend([base_activations[i][:,-1,:].detach()[0].cpu().numpy(),
                                           src_activations[i][:,-1,:].detach()[0].cpu().numpy()])
            train_label[i - 1].extend([label_mapping[example.base_label], label_mapping[example.src_label]])

    
    print("====================loading test set activation====================")
    iterator_test = tqdm(evalset)
    for example in iterator_test:
        test_base_inputs = example.base
        test_base_activations = get_single_res(test_base_inputs["text"], test_base_inputs["image"])

        # 1 ~ 32
        for i in range(1, 33):
            test_activation[i - 1].extend(
                        [test_base_activations[i][:,-1,:].detach()[0].cpu().numpy()]
                    )
            test_label[i - 1].extend([label_mapping[example.base_label]])
        
    print("====================traning=====================")
    for layer in tqdm(range(1, 33),total=32):
        # train logistic regression
        lr = LogisticRegression(random_state=42, max_iter=1000).fit(
                train_activation[layer-1], train_label[layer-1]
            )
        
        # stats
        acc = lr.score(test_activation[layer-1], test_label[layer-1])
        f1 = f1_score(test_label[layer-1], lr.predict(test_activation[layer-1]))
        stats.append({"layer": layer, "position": "last token", "acc": acc, "f1": f1})
        print(f"the layer is {layer}")
        print(f"acc: {acc:.3%}, f1: {f1:.3f}")
df = pd.DataFrame(stats)
df.to_csv(".../code/prismatic-vlms/probe/800/prefix_prompt_224.csv")

