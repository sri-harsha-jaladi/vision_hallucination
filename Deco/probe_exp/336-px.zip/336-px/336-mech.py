import argparse
import torch
import time
from llava.constants import (
    IMAGE_TOKEN_INDEX,
    DEFAULT_IMAGE_TOKEN,
    DEFAULT_IM_START_TOKEN,
    DEFAULT_IM_END_TOKEN,
    IMAGE_PLACEHOLDER,
)
from llava.conversation import conv_templates, SeparatorStyle
from llava.model.builder import load_pretrained_model
from llava.utils import disable_torch_init
from llava.mm_utils import (
    process_images,
    tokenizer_image_token,
    get_model_name_from_path,
    KeywordsStoppingCriteria,
)

from PIL import Image
import base64
import requests
from PIL import Image
from io import BytesIO
import re


def image_parser(args):
    out = args.image_file.split(args.sep)
    return out


def load_image(image_file):
    if image_file.startswith("http") or image_file.startswith("https"):
        response = requests.get(image_file)
        image = Image.open(BytesIO(response.content)).convert("RGB")
    else:
        image = Image.open(image_file).convert("RGB")
    return image


def load_images(image_files):
    out = []
    for image_file in image_files:
        image = load_image(image_file)
        out.append(image)
    return out

model_name = get_model_name_from_path(".../llava-v1.5-7b")
tokenizer, model, image_processor, context_len = load_pretrained_model(
        ".../llava-v1.5-7b", None, model_name, device_map="cuda:5", device="cuda:5"
    )

# model = model.bfloat16()

def eval_model(args):
    # Model
    disable_torch_init()
    qs = args.query

    if "llama-2" in model_name.lower():
        conv_mode = "llava_llama_2"
    elif "v1" in model_name.lower():
        conv_mode = "llava_v1"
    elif "mpt" in model_name.lower():
        conv_mode = "mpt"
    else:
        conv_mode = "llava_v0"

    if args.conv_mode is not None and conv_mode != args.conv_mode:
        print(
            "[WARNING] the auto inferred conversation mode is {}, while `--conv-mode` is {}, using {}".format(
                conv_mode, args.conv_mode, args.conv_mode
            )
        )
    else:
        args.conv_mode = conv_mode

    # conv = conv_templates[args.conv_mode].copy()
    # conv.append_message(conv.roles[0], qs)
    # conv.append_message(conv.roles[1], None)
    prompt = qs

    image_files = image_parser(args)
    images = load_images(image_files)
    images_tensor = process_images(
        images,
        image_processor,
        model.config
    ).to(model.device, dtype=torch.float16)

    input_ids = (
        tokenizer_image_token(prompt, tokenizer, IMAGE_TOKEN_INDEX, return_tensors="pt")
        .unsqueeze(0)
        .cuda(5)
    )

    with torch.inference_mode():
        # 直接forward
        output_dict = model(
            input_ids,
            images=images_tensor,
            output_hidden_states=True,
            return_dict = True,
        )
    return output_dict.hidden_states
    



# 选取定量数据


def get_single_res(input, image_path):
    dict_res = {
                "conv_mode": "llava_v1",
                "model_path": ".../llava-v1.5-7b",
                "model_base": None,
                "model_name": get_model_name_from_path(".../llava-v1.5-7b"),
                "query": input,
                "conv_mode": None,
                "image_file": image_path,
                "sep": ",",
                "temperature": -1,
                "top_p": None,
                "num_beams": 1,
                "max_new_tokens": 2048
            }
    args = type('Args', (), dict_res)()
    res = eval_model(args)
    return res



from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score
import pandas as pd
from probe_mllmmech_dataload import *
total_steps = 1500
trainset = generate_n_doable_examples(total_steps, tokenizer)
yes_evalset = get_yes_pope_data(tokenizer)
no_evalset = get_no_pope_data(tokenizer)

stats = []
num_layers = 32 


label_mapping = {4874: 0, 694: 1}#yes:4874, no:694

train_activation = [[] for _ in range(32)]
train_label = [[] for _ in range(32)]

yes_test_activation = [[] for _ in range(32)]
yes_test_label = [[] for _ in range(32)]

no_test_activation = [[] for _ in range(32)]
no_test_label = [[] for _ in range(32)]

all_test_activation = [[] for _ in range(32)]
all_test_label = [[] for _ in range(32)]


# loop over layers and positions
with torch.no_grad():
    # activations, labels = [], []
    print("====================loading train set activation====================")
    iterator = tqdm(trainset)
    for example in iterator:
        # forward pass
        base_inputs = example.base
        base_activations = get_single_res(base_inputs["text"], base_inputs["image"])
        
        src_inputs = example.src
        src_activations = get_single_res(src_inputs["text"], src_inputs["image"])
         
        # 1 ~ 32
        for i in range(1, 33):
            train_activation[i - 1].extend([base_activations[i][:,-1,:].detach()[0].cpu().numpy(),
                                           src_activations[i][:,-1,:].detach()[0].cpu().numpy()])
            train_label[i - 1].extend([label_mapping[example.base_label], label_mapping[example.src_label]])

    
    print("====================loading yes test set activation====================")
    iterator = tqdm(yes_evalset)
    for example in iterator:
        base_inputs = example.base
        base_activations = get_single_res(base_inputs["text"], base_inputs["image"])

        # 1 ~ 32
        for i in range(1, 33):
            yes_test_activation[i - 1].extend(
                        [base_activations[i][:,-1,:].detach()[0].cpu().numpy()]
                    )
            yes_test_label[i - 1].extend([label_mapping[example.base_label]])
            
            all_test_activation[i - 1].extend(
                        [base_activations[i][:,-1,:].detach()[0].cpu().numpy()]
                    )
            all_test_label[i - 1].extend([label_mapping[example.base_label]])
            
            
    print("====================loading no test set activation====================")
    iterator = tqdm(no_evalset)
    for example in iterator:
        base_inputs = example.base
        base_activations = get_single_res(base_inputs["text"], base_inputs["image"])

        # 1 ~ 32
        for i in range(1, 33):
            no_test_activation[i - 1].extend(
                        [base_activations[i][:,-1,:].detach()[0].cpu().numpy()]
                    )
            no_test_label[i - 1].extend([label_mapping[example.base_label]])
            
            all_test_activation[i - 1].extend(
                        [base_activations[i][:,-1,:].detach()[0].cpu().numpy()]
                    )
            all_test_label[i - 1].extend([label_mapping[example.base_label]])
        
    print("====================traning=====================")
    for layer in tqdm(range(1, 33),total=32):
        # train logistic regression
        lr = LogisticRegression(random_state=42, max_iter=1000).fit(
                train_activation[layer-1], train_label[layer-1]
            )
        
        # stats
        yes_acc = lr.score(yes_test_activation[layer-1], yes_test_label[layer-1])
        no_acc = lr.score(no_test_activation[layer-1], no_test_label[layer-1])
        all_acc = lr.score(all_test_activation[layer-1], all_test_label[layer-1])
        f1 = f1_score(all_test_label[layer-1], lr.predict(all_test_activation[layer-1]))
        stats.append({"layer": layer, "position": "last token", "yes_acc": yes_acc, "no_acc": no_acc, "all_acc": all_acc, "f1": f1})
        print(f"the layer is {layer}")
        print(f"yes_acc: {yes_acc:.3%}, no_acc: {no_acc:.3f}, all_acc: {all_acc:.3f}, f1: {f1:.3f}")
df = pd.DataFrame(stats)
df.to_csv(".../code/LLaVA/res/coco_res/sample_adversarial_train_1500.csv")

