from collections import namedtuple
from tqdm import tqdm
import random
import numpy as np

prefix_prompt = "A chat between a curious human and an artificial intelligence assistant. The assistant gives helpful, detailed, and polite answers to the human's questions. "
# prefix_prompt = ""

random.seed(42)
np.random.seed(42)

Example = namedtuple("Example", ["base", "src", "base_label", "src_label"])

all_data = {"yes":[],"no":[]}
import json
with open(".../train_set/coco_pope_adversarial.json", "r", encoding="utf-8") as f:
    for line in f.readlines():
        data = json.loads(line)
        all_data[data["label"]].append(data)
        
f.close()



def get_yes_pope_data(tokenizer):
    # eval_data = {"yes":[],"no":[]}
    eval_examples = []
    with open(".../test_set/all.json", "r", encoding="utf-8") as f2:
        f_data = json.load(f2)
    for sigle_data in f_data:
        for text_line in sigle_data["data"]:
            # obj = text_line["text"].split("there is a")[-1]
            obj = text_line["text"].split("there is a")[-1]
            obj = " The image contains" + obj
            # obj = "Does the image contain" + obj +"?"
            if text_line["label"] == "no":
                continue
            base = {"image":sigle_data["image"], "text":prefix_prompt+"USER: <image>\nDescribe the image. ASSISTANT:" + obj}
            # base = {"image":sigle_data["image"], "text":prefix_prompt+"USER: <image>\n{obj} ASSISTANT:".format(obj=obj)}
            
            base_label = tokenizer.encode(" yes")[-1]
            src = {}
            src_label= base_label 
            eval_examples.append(Example(base, src, base_label,src_label))
        
    return eval_examples


def get_no_pope_data(tokenizer):
    # eval_data = {"yes":[],"no":[]}
    eval_examples = []
    with open(".../test_set/all.json", "r", encoding="utf-8") as f2:
        f_data = json.load(f2)
    for sigle_data in f_data:
        for text_line in sigle_data["data"]:
            # obj = text_line["text"].split("there is a")[-1]
            obj = text_line["text"].split("there is a")[-1]
            obj = " The image contains" + obj
            # obj = "Does the image contain" + obj +"?"
            if text_line["label"] == "yes":
                continue
            base = {"image":sigle_data["image"], "text":prefix_prompt+"USER: <image>\nDescribe the image. ASSISTANT:" + obj}
            # base = {"image":sigle_data["image"], "text":prefix_prompt+"USER: <image>\n{obj} ASSISTANT:".format(obj=obj)}
            
            base_label = tokenizer.encode(" no")[-1]
            src = {}
            src_label= base_label 
            eval_examples.append(Example(base, src, base_label,src_label))
        
    return eval_examples
            
    
    
    
    
def sample_example(tokenizer):
    # sample labels (not matching)
    base_label = random.choice(list(all_data.keys()))
    src_label = [key for key in all_data if key != base_label][0]
    # sample names
    base_data = random.choice(all_data[base_label])
    src_data = random.choice(all_data[src_label])
    
    base_obj = base_data["text"].split("There is a")[-1]
    base_obj = " The image contains" + base_obj
    # base_obj = "Does the image contain" + base_obj +"?"
    src_obj = src_data["text"].split("There is a")[-1]
    src_obj = " The image contains" + src_obj
    # src_obj = "Does the image contain" + src_obj +"?"
    # base = {"image":base_data["image"], "text":prefix_prompt+"USER: <image>\n{obj} ASSISTANT:".format(obj=base_obj)}
    # src = {"image":src_data["image"], "text":prefix_prompt+"USER: <image>\n{obj} ASSISTANT:".format(obj=src_obj)}
    base = {"image":base_data["image"], "text":prefix_prompt+"USER: <image>\nDescribe the image. ASSISTANT:"+base_obj}
    src = {"image":src_data["image"], "text":prefix_prompt+"USER: <image>\nDescribe the image. ASSISTANT:"+src_obj}
    
    base_label = tokenizer.encode(" " + base_label)[-1]
    src_label = tokenizer.encode(" " + src_label)[-1]
    return Example(base, src, base_label, src_label)



def generate_n_doable_examples(n, tokenizer):
    examples = []
    iterator = tqdm(range(n))
    while len(examples) < n:
        ex = sample_example(tokenizer)
        examples.append(ex)
        iterator.update(1)
    return examples

